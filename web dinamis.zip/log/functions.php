<?php
$conn = mysqli_connect('localhost','root','','db_rafi');

function query($query){

	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)){
		$row[]= $row;
	}
	return $rows;

}

function tambah ($data){ 
	global $conn;
	global $query;

	    $nama   = ($data["nama"]);
		$telp   = ($data["telp"]);
		$email  = ($data["email"]);
		$pass   = ($data["password"]);

		$query = ("INSERT INTO tb_user VALUES('', '$nama', '$telp', '$email', '$pass')");
			mysqli_query($conn, $query);
			mysqli_affected_rows($conn);

}



?>