<!DOCTYPE html>
<html>
<head>
	<title>Halaman registrasi</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body style="background-color: #e0d7e7;">
	<div class="container">
		<div class="header">
		Rafi Coding.Com
		</div>

		<div class="content">
			<div class="box-daftar">
				<div class="head-daftar">Silahkan isi</div>

				<form action="proses_registrasi.php" method="post">
					<label>Nama</label><br>
					<input type="text" name="nama"><br>
					<label>telepon</label><br>
					<input type="text" name="telepon"><br>
					<label>email</label><br>
					<input type="email" name="email"><br>
					<label>password</label><br>
					<input type="password" name="password"><br>
					<br>
					<input type="submit" name="submit" value="masuk"><br>

				</form>
				
				
			</div>
		</div>

		<div class="footer">
			Copyright &copy; Rafi Web.
		</div>
	</div>
</body>
</html>