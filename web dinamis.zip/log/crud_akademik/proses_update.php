<?php 
	require 'config.php';

	if (isset($_POST['submit'])) {
		$id         = $_GET['id'];
		$nim        = $_POST['nim'];
		$nama       = $_POST['nama'];
		$jenis      = $_POST['jenis'];
		$artikel    = $_POST['artikel'];
		$tanggal    = $_POST['tanggal'];

		$sql     = "UPDATE siswa SET nim='$nim',nama='$nama',jenis='$jenis',artikel='$artikel',tanggal='$tanggal' WHERE id='$id'";
		$query   = mysqli_query($koneksi,$sql);
		if ($sql) {
			
			echo "
				<script>
						alert('data berhasil diubah');
						document.location.href='index.php';
				</script>

			";
		}else{
			echo "
				<script>
						alert('data gagal diubah');
						document.location.href='tambah.php';
				</script>

			";
		}
	}
 ?>