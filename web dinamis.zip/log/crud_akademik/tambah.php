
<?php
	$koneksi = mysqli_connect('localhost','root','','dbsiswa');
	if (isset($_POST['submit'])) {
		$nim        = $_POST['nim'];
		$nama       = $_POST['nama'];
		$jenis      = $_POST['jenis'];
		$artikel    = $_POST['artikel'];
		$tanggal    = $_POST['tanggal'];

		$sql     = "INSERT INTO siswa SET id='',nim='$nim',nama='$nama',jenis='$jenis',artikel='$artikel',tanggal='$tanggal'";
		$query   = mysqli_query($koneksi,$sql);
		if (mysqli_affected_rows($koneksi)) {
			
			echo "
				<script>
						alert('data berhasil ditambah');
						document.location.href='index.php';
				</script>

			";
		}else{
			echo "
				<script>
						alert('data gagal ditambah');
						document.location.href='tambah.php';
				</script>

			";
		}
	}
?>
<html>
<head>
	<title>Silahkan Tambah Data</title>
</head>
<body style="background-color: #e4e9f3;">
	<h1 align="center" style="height: 75px;background-color:#ea4545;margin-top: -10px;border: 3px solid black;line-height: 62px;">Halaman Admin</h1>
	
	<p align="center" style="background-color: #21ff00;height: 100px;margin-top: -24px;border: 3px solid black;">
		<a href="index.php"><button style=";height: 30px;height: 33px;background-color: #000cff;margin-top: 25px;width: 70px;">HOME</button></a>
	
	<form action="" method="POST" style="margin-left: 392px;margin-top: 81;height: 308px;width: 457px;background-color: #0ef000;padding-left: 128;
										 border: 3px solid #745252;"><label>nim</label><br>
		<input type="text" name="nim"><br>

		<label>nama</label><br>
		<input type="text" name="nama"><br>

		<label>sumber</label><br>
		<input type="text" name="jenis"><br>

		<label>artikel</label><br>
		<textarea name="artikel"> </textarea><br>


		<label>tanggal</label><br>
		<input type="date" name="tanggal"><br>
		<br>
		<input type="submit" name="submit" value="MASUKAN DATA">
	</form>

</body>
</html>
