<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<div id="menu">
		<ul id="ul">
			<li id="li">
				<a href="index.php ">HOME</a> 
			</li>

				<label>atau</label>
			<li id="lii">

				<a href="tambah.php">INSERT</a>
			</li>
		</ul>
	</div>

</body>
</html>
