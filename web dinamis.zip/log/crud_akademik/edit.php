<html>
<head>
</head>

<body style="background-color: #c6d5d5;">
 
 <h1 align = "center" style="height: 66px;background-color: #a8aa9d;margin-top: -10px;line-height: 52px;">Edit Data</h1>
 <p align = "center" style="height: 156px;background-color: #acc9c9;margin-top: -35px;line-height: 143px;">
  <a href = "index.php"><button style="height: 30px;height: 33px;background-color: #000cff;">Home</button></a> atau
  <a href = "tambah.php"><button style="height: 30px;height: 33px;background-color: #000cff;">Input Data </button></a> 
 </p>
<?php
 include 'config.php';
 $id = $_GET['id'];

 $query = "SELECT * FROM siswa WHERE id='$id'";
 $sql   = mysqli_query($koneksi,$query);
 while ($data=mysqli_fetch_assoc($sql)) {
   

?>
 <form action ="proses_update.php?id=<?php echo $data['id']; ?>" method="POST" style= "width: 332px;height: 359px;background-color: #f0bc6e;margin-left: 409px;                                                                                    padding-left: 193px;padding-top: 41px;margin-top: 19px;">
    <label>nim</label><br>
    <input type="text" name="nim" value="<?php echo $data['nim'];?>"><br>

    <label>nama</label><br>
    <input type="text" name="nama" value="<?php echo $data['nama'];?>"><br>

    <label>sumber</label><br>
    <input type="text" name="jenis"  value="<?php echo $data['jenis'];?>"><br>

    <label>artikel</label><br>
    <textarea name="artikel"><?php echo $data['artikel'];?></textarea><br>


    <label>tanggal</label><br>
    <input type="date" name="tanggal"  value="<?php echo $data['tanggal'];?>"><br>

    <input type="submit" name="submit" value="masuk">
  </form>
<?php } ?>
</body>
</html>

