<html style="background-color:#e0e0eb">
<head>
	<title>Selamat Datang</title>
</head>
<body>

<p align = "center">
	<a href="../login.php"><button style="margin-left: 1100px;height: 30px;height: 33px;background-color: #000cff;"> Logout</button></a>
	<a href="tambah.php"><button style="margin-left: -1190px;height: 30px;height: 33px;background-color: #000cff;">Tambah Data</button></a>
</p>

<form action = "" method = "POST">
	<table align = "center" cellspacing = "0" cellpadding = "5" border = "3px" style="width: 1058; text-align: center;">
		<h1 style="height: 79px;width: px;background-color: #5bc0cc;text-align: center;padding-bottom: -5px;padding-top: 26px;margin-top: -56px;
				   border: 2px solid black;"> Selamat Datang User</h1>
		<tr style="background-color: #c3ff00;height: 100px;text-align: center;">
			<td>No</td>
			<td>JENIS</td>
			<td>SUMBER</td>
			<td>ARTIKEL</td>
			<td>tanggal</td>
			<td>OPSI</td>
		</tr>
	
<?php
	include 'config.php';
	$view = $koneksi -> query ("SELECT * FROM siswa");
	while($row=$view->fetch_array()){
?>
	<tr>
		<td> <?php echo $row['nim']; ?> </td>
		<td> <?php echo $row['nama']; ?> </td>
		<td> <?php echo $row['jenis']; ?> </td>
		<td> <?php echo substr($row['artikel'], 0,20); echo"..."; ?> </td>
		<td> <?php echo $row['tanggal']; ?> </td>
		<td>
			<a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> ||
			<a href="delete.php?del=<?php echo $row['id']; ?>">Hapus</a>
		</td>
	</tr>
	
	<?php
	}
	?>
	</table>
</form>
</body>
</html>