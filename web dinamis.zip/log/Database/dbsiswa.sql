-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 07 Mei 2018 pada 09.27
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 7.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbsiswa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nim` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `artikel` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nim`, `nama`, `jenis`, `artikel`, `tanggal`) VALUES
(1, '12', 'struktur Desa Gemuruh', 'Desa', 'Struktur Organisasi Pemerintahan Desa\r\n\r\nLembaga Pemerintahan di Desa Gemuruh  terdiri atas 2 (dua) lembaga yang antara lain : Pemerintah Desa dan Badan Permusyawaratan Desa (BPD) Desa Gemuruh Badan Permusyawaratan Desa merupakan lembaga legislasi desa, sedangkan Pemerintah Desa adalah lembaga eksekutif pemerintahan desa. Kedua lembaga desa ini mempunyai hubungan koordinasi.\r\nPemerintah Desa Gemuruh terdiri atas ; 1) Kepala Desa dan 2) Perangkat Desa. Dimana dalam hal ini Perangkat Desa terdiri dari : Unsur Sekretariat Desa, unsur Kewilayahan dan unsur pelaksana tekhnis lapangan. \r\nUnsur sekretariat desa terbagi atas 5 lima) Kepala Urusan yakni : Kaur Keuangan, Kaur Kesra, Kaur Pemerintahan, Kaur Pembangunan dan Kaur Umum. Masing-masing Kaur tersebut bertanggungjawab kepada Sekretaris Desa, sedangkan Sekretaris Desa bertanggung jawab kepada Kepala Desa.\r\nUnsur Kewilayahan terdisi atas dusun-dusun yaitu dusun Sireok, dusun Kesatrian, dusun Kaliwuluh dan Dusun Wiragunan, sedangkan unsur pelaksana teknis lapangan terdiri dari kayim dan ulu-ulu. Unsur Kewilayahan dan unsur pelaksana teknis lapangan tersebut bertanggungjawab langsung kepada Kepala Desa dan memiliki hubungan koordinasi dengan Sekretaris Desa.\r\nUnsur kewilayahan (dusun) dalam pelaksanaan tugas dan tanggung jawabnya dibantu oleh Pengurus RW dan RT yang ada di wilayahnya masing-masing. \r\nSementara Pemerintah Desa Gemuruh dalam menjalankan fungsi pembangunan dan pemberdayaan masyarakat, maka Pemerintah Desa dibantu oleh Lembaga Pemberdayaan Masyarakat Desa (LPMD) yang merupakan mitra Pemerintah Desa. \r\nUntuk lebih jelasnya Struktur Organisasi Pemerintah Desa Gemuruh adalah sebagai berikut:  \r\n', '2018-05-23'),
(10, '111111', 'rfrfrfrf', 'wkwkwkland', ' lwntgjkewbfjkbewbwefblwebfowefoibewoifbweofbwebvoewinf', '2018-05-19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
