<?php 
	$koneksi = mysqli_connect('localhost','root','','db_rafi');
	if (isset($_POST['submit'])) {
		$username = $_POST['user'];
		$password = $_POST['password'];

		$query = "SELECT * FROM tb_user WHERE password = '$password'";
		$sql    = mysqli_query($koneksi,$query);
		$chek   = mysqli_num_rows($sql);
		if ($chek == 1) {
			echo "
				<script>
						alert('WELCOM TO MY WEB (:');
						document.location.href='crud_akademik/index.php';
				</script>

			";
		}else{
			echo "
				<script>
						alert('SORY CANOT LOGIN ): ');
						document.location.href='login.php';
				</script>

			";
		}
	}



 ?>