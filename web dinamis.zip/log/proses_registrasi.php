<?php 
	require 'koneksi.php';
	if (isset($_POST['submit'])) {
		$nama     = $_POST['nama'];
		$telepon  = $_POST['telepon'];
		$email    = $_POST['email'];
		$password = $_POST['password'];

		$sql     = "INSERT INTO tb_user VALUES('','$nama','$telepon', '$email', '$password')";
		$query   = mysqli_query($koneksi,$sql);
		if (mysqli_affected_rows($koneksi)) {
			
			echo "
				<script>
						alert('data berhasil ditambah');
						document.location.href='login.php';
				</script>

			";
		}else{
			echo "
				<script>
						alert('data gagal ditambah');
						document.location.href='tambah.php';
				</script>

			";
		}

	}

 ?>