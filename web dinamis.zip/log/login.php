<!DOCTYPE html>
<html>
<head>
	<title>Halaman login</title>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body style= >
	<div class="container">
		<div class="header">
		Rafi Coding.Com
		</div>

		<div class="content">
			<div class="box-daftar">
				<div class="head-daftar">
				Silahkan Login
				</div>
				<form action="proses_login.php" method="post">
				User name<br>
				<input type="text" name="user"><br>
				password<br>
				<input type="password" name="password"><br>
				<br>
				<button type="submit" name="submit" value="masuk" style="height: 30px;height: 33px;background-color: #000cff;margin-top: -11px;width: 70px;">login</button><br>
				<br><br><br><br>
				<a href="registrasi.php">Belum Punya akun?</a>
				</form>
	
		<div class="footer">
			Copyright &copy; Rafi Web.
		</div>
	</div>
</body>
</html>